This is the README for the SuperPutty Application

For License information please read the License.txt included with the download

For issue tracking, documentation and downloads please visit the Google Code Project
http://code.google.com/p/superputty/
